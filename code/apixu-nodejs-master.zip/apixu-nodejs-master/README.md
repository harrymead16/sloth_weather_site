# apixu-nodejs

NodeJS library for Apixu Weather API
